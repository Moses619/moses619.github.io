<!DOCTYPE html>
<html dir="ltr" lang="en-gb">
<head>
	<meta charset="utf-8">
	<meta content="width=device-width, initial-scale=1" name="viewport">
	<title>arrowthemes - Premium Joomla templates</title>
	<meta content="Premium Joomla templates and HTML templates" name="description">
	<meta content="joomla, joomla templates, html5, arrowthemes, html templates, free joomla templates" name="keywords">
	<meta content="arrowthemes" name="author">
	<link href="favicon.ico" rel="shortcut icon" type="image/x-icon">
	<link href="css/style.min.css" rel="stylesheet">
</head>
<body id="body_id" class="has_envato_iframe">
	<script>
	if (window.top.location !== location) {
    var css = '.bg-dark, .tm-toolbar { display: none; } ' +
		'body.has_envato_iframe {top: 0 !important}' + 
		'#resizer embed, #resizer iframe, #resizer object {margin-top: 0;}' +
		'#resizer iframe {height: 100vh !important}',
		head = document.head || document.getElementsByTagName('head')[0],
		style = document.createElement('style');
		document.getElementById("body_id").classList.add('envato-preview');
	style.type = 'text/css';
	style.appendChild(document.createTextNode(css));
	head.appendChild(style);
}</script>
	<div id="loader">
		<span></span>
	</div>
	<div class="bg-dark" id="bg-dark"></div>
	<div class="tm-toolbar">
		<a class="logo pull-left" href="https://arrowthemes.com/shop" target="_blank" title="arrowthemes"></a>
		<div class="container">
			<div class="tm-select-themes">
				<a class="beluga" data-buy="https://arrowthemes.com/template/joomla/download-beluga" data-style="6" data-theme="beluga" href="#" id="tm-choose-theme" rel="https://demo.arrowthemes.com/joomla/beluga/?style=,default,blue,olive,orange,purple,navy">beluga</a>
				<div class="tm-demo-showcase" id="tm-demo-showcase">
					<div class="tm-demo-preview">
						<ul class="list tm-switcher-content">
							<li class="tab-pane active" id="beluga">
								<div class="teaser-image">
									<img alt="beluga Joomla template" height="300" src="images/presets/beluga.jpg" width="220">
								</div>
								<h3>Beluga</h3>
								<p class="meta"><span>a modern clean creative Joomla template for professionals.</span></p>
								<p class="meta"><span>Compatibility:</span> Joomla! 3.x</p>
								<a class="button purchase" href="https://arrowthemes.com/template/joomla/download-beluga" target="_self" onclick="ga('send','event','Beluga purchase','Click','Go to Themeforest');">Buy now</a>
							</li>
							<li class="tab-pane" id="lawford">
								<div class="teaser-image">
									<img alt="lawford Joomla template" height="300" src="images/presets/lawford.jpg" width="220">
								</div>
								<h3>Lawford</h3>
								<p class="meta"><span>a unique micro-niche lawyer and law firm Joomla template.</span></p>
								<p class="meta"><span>Compatibility:</span> Joomla! 3.x</p>
								<a class="button purchase" href="https://arrowthemes.com/template/joomla/download-lawford" target="_self" onclick="ga('send','event','Lawford purchase','Click','Go to Themeforest');">Buy now</a>
							</li>
							<li class="tab-pane" id="utouch">
								<div class="teaser-image">
									<img alt="utouch Joomla template" height="300" src="images/presets/utouch.jpg" width="220">
								</div>
								<h3>Utouch</h3>
								<p class="meta"><span>a digital marketing, startup multi-purpose Joomla template.</span></p>
								<p class="meta"><span>Compatibility:</span> Joomla! 3.x</p>
								<a class="button purchase" href="https://arrowthemes.com/template/joomla/download-utouch" target="_self" onclick="ga('send','event','Utouch purchase','Click','Go to Themeforest');">Buy now</a>
							</li>
							<li class="tab-pane" id="buckle">
								<div class="teaser-image">
									<img alt="buckle Joomla template" height="300" src="images/presets/buckle.jpg" width="220">
								</div>
								<h3>Buckle</h3>
								<p class="meta"><span>a carefully crafted, bold multi-concept Joomla template</span></p>
								<p class="meta"><span>Compatibility:</span> Joomla! 3.x</p>
								<a class="button purchase" href="https://arrowthemes.com/template/joomla/download-buckle" target="_self" onclick="ga('send','event','Buckle purchase','Click','Go to Themeforest');">Buy now</a>
							</li>
							<li class="tab-pane" id="recover">
								<div class="teaser-image">
									<img alt="recover Joomla template" height="300" src="images/presets/recover.jpg" width="220">
								</div>
								<h3>Recover</h3>
								<p class="meta"><span>an impressive multi-niche template for Joomla</span></p>
								<p class="meta"><span>Compatibility:</span> Joomla! 3.x</p>
								<a class="button purchase" href="https://arrowthemes.com/template/joomla/download-recover" target="_self" onclick="ga('send','event','Recover purchase','Click','Go to Themeforest');">Buy now</a>
							</li>
							<li class="tab-pane" id="gravity">
								<div class="teaser-image">
									<img alt="gravity Joomla template" height="300" src="images/presets/gravity.jpg" width="220">
								</div>
								<h3>Gravity</h3>
								<p class="meta"><span>education, schools &amp; university template for Joomla</span></p>
								<p class="meta"><span>Compatibility:</span> Joomla! 3.x</p>
								<a class="button purchase" href="https://arrowthemes.com/template/joomla/download-gravity" target="_self" onclick="ga('send','event','Gravity purchase','Click','Go to Themeforest');">Buy now</a>
							</li>
							<li class="tab-pane" id="sandal">
								<div class="teaser-image">
									<img alt="sandal Joomla template" height="300" src="images/presets/sandal.jpg" width="220">
								</div>
								<h3>Sandal</h3>
								<p class="meta"><span>finance &amp; consultancy business theme for Joomla</span></p>
								<p class="meta"><span>Compatibility:</span> Joomla! 3.x</p>
								<a class="button purchase" href="https://arrowthemes.com/template/joomla/download-sandal" target="_self" onclick="ga('send','event','Sandal purchase','Click','Go to Themeforest');">Buy now</a>
							</li>
							<li class="tab-pane" id="gaucho">
								<div class="teaser-image"><img alt="gaucho Joomla template" height="300" src="images/presets/gaucho.jpg" width="220"></div>
								<h3>Gaucho</h3>
								<p class="meta"><span>an exquisite restaurant or food blog theme for Joomla</span></p>
								<p class="meta"><span>Compatibility:</span> Joomla! 3.x</p>
								<a class="button purchase" href="https://arrowthemes.com/template/joomla/download-gaucho" target="_self" onclick="ga('send','event','Gaucho purchase','Click','Go to Themeforest');">Buy now</a>
							</li>
							<li class="tab-pane" id="celsius">
								<div class="teaser-image"><img alt="celsius Joomla template" height="170" src="images/presets/celsius.png" width="220"></div>
								<h3>Celsius</h3>
								<p class="meta"><span>a magnificent portfolio or agency theme for Joomla</span></p>
								<p class="meta"><span>Compatibility:</span> Joomla! 3.x</p>
								<a class="button purchase" href="https://arrowthemes.com/template/joomla/download-celsius" target="_self" onclick="ga('send','event','Celsius purchase','Click','Go to Themeforest');">Buy now</a>
							</li>
							<li class="tab-pane" id="saffron">
								<div class="teaser-image"><img alt="saffron Joomla template" height="170" src="images/presets/saffron.png" width="220"></div>
								<h3>Saffron</h3>
								<p class="meta"><span>a beautifully crafted multi-concept theme for Joomla</span></p>
								<p class="meta"><span>Compatibility:</span> Joomla! 3.x</p>
								<a class="button purchase" href="https://arrowthemes.com/template/joomla/download-saffron" target="_self" onclick="ga('send','event','Saffron purchase','Click','Go to Themeforest');">Buy now</a>
							</li>
							<li class="tab-pane" id="mistral">
								<div class="teaser-image"><img alt="mistral Joomla template" height="170" src="images/presets/mistral.png" width="220"></div>
								<h3>Mistral</h3>
								<p class="meta"><span>a bold all-in-one Joomla business theme with projects in mind</span></p>
								<p class="meta"><span>Compatibility:</span> Joomla! 3.x</p>
								<a class="button purchase" href="https://arrowthemes.com/template/joomla/download-mistral" target="_self" onclick="ga('send','event','Mistral purchase','Click','Go to Themeforest');">Buy now</a>
							</li>
							<li class="tab-pane" id="legend">
								<div class="teaser-image"><img alt="legend Joomla template" height="170" src="images/presets/legend.png" width="220"></div>
								<h3>Legend</h3>
								<p class="meta"><span>a stunning business Joomla theme for products and services</span></p>
								<p class="meta"><span>Compatibility:</span> Joomla! 3.x</p>
								<a class="button purchase" href="https://arrowthemes.com/template/joomla/download-legend" target="_self" onclick="ga('send','event','Legend purchase','Click','Go to Themeforest');">Buy now</a>
							</li>
							<li class="tab-pane" id="fontaine">
								<div class="teaser-image"><img alt="fontaine Joomla template" height="170" src="images/presets/fontaine.png" width="220"></div>
								<h3>Fontaine</h3>
								<p class="meta"><span>a clean, professional business theme for Joomla</span></p>
								<p class="meta"><span>Compatibility:</span> Joomla! 3.x</p>
								<a class="button purchase" href="https://arrowthemes.com/template/joomla/download-fontaine" target="_self" onclick="ga('send','event','Fontaine purchase','Click','Go to Themeforest');">Buy now</a>
							</li>
							<li class="tab-pane" id="vantage">
								<div class="teaser-image"><img alt="vantage Joomla template" height="170" src="images/presets/vantage.png" width="220"></div>
								<h3>Vantage</h3>
								<p class="meta"><span>a full width business or portfolio theme for Joomla</span></p>
								<p class="meta"><span>Compatibility:</span> Joomla! 3.x</p>
								<a class="button purchase" href="https://arrowthemes.com/template/joomla/download-vantage" target="_self" onclick="ga('send','event','Vantage purchase','Click','Go to Themeforest');">Buy now</a>
							</li>
							<li class="tab-pane" id="lighthouse">
								<div class="teaser-image"><img alt="lighthouse Joomla template" height="170" src="images/presets/lighthouse.png" width="220"></div>
								<h3>Lighthouse</h3>
								<p class="meta"><span>an intuitive church or non profit organization theme</span></p><br>
								<p class="meta"><span>Compatibility:</span> Joomla! 3.x</p>
								<a class="button purchase" href="https://arrowthemes.com/template/joomla/download-lighthouse" target="_self" onclick="ga('send','event','Lighthouse purchase','Click','Go to Themeforest');">Buy now</a>
							</li>
							<li class="tab-pane" id="fidelity">
								<div class="teaser-image"><img alt="fidelity Joomla template" height="170" src="images/presets/fidelity.png" width="220"></div>
								<h3>Fidelity</h3>
								<p class="meta"><span>a clean and elegant business theme for Joomla</span></p>
								<p class="meta"><span>Compatibility:</span> Joomla! 3.x</p>
								<a class="button purchase" href="https://arrowthemes.com/template/joomla/download-fidelity" target="_self" onclick="ga('send','event','Fidelity purchase','Click','Go to Themeforest');">Buy now</a>
							</li>
							<li class="tab-pane" id="uneedo">
								<div class="teaser-image"><img alt="uneedo Joomla template" height="170" src="images/presets/uneedo.png" width="220"></div>
								<h3>Uneedo</h3>
								<p class="meta"><span>a revolutionary community theme for Joomla</span></p>
								<p class="meta"><span>Compatibility:</span> Joomla! 3.x</p>
								<a class="button purchase" href="https://arrowthemes.com/template/joomla/download-uneedo" target="_self" onclick="ga('send','event','Uneedo purchase','Click','Go to Themeforest');">Buy now</a>
							</li>
							<li class="tab-pane" id="sauna">
								<div class="teaser-image"><img alt="sauna Joomla template" height="170" src="images/presets/sauna.png" width="220"></div>
								<h3>Sauna</h3>
								<p class="meta"><span>a unique health and beauty theme for Joomla</span></p>
								<p class="meta"><span>Compatibility:</span> Joomla! 3.x</p>
								<a class="button purchase" href="https://arrowthemes.com/template/joomla/download-sauna" target="_self" onclick="ga('send','event','Sauna purchase','Click','Go to Themeforest');">Buy now</a>
							</li>
							<li class="tab-pane" id="abana">
								<div class="teaser-image"><img alt="abana Joomla template" height="170" src="images/presets/abana.png" width="220"></div>
								<h3>Abana</h3>
								<p class="meta"><span>an elegant business and professional theme for Joomla</span></p>
								<p class="meta"><span>Compatibility:</span> Joomla! 3.x</p>
								<a class="button purchase" href="https://arrowthemes.com/template/joomla/download-abana" target="_self" onclick="ga('send','event','Abana purchase','Click','Go to Themeforest');">Buy now</a>
							</li>
						</ul>
					</div>
					<div class="carousel slide" data-ride="carousel" id="themes-gallery">
						<div class="carousel-inner">
							<div class="active item">
								<ul class="tm-switcher" role="tablist">
									<li>
										<a class="active-theme" data-buy="https://arrowthemes.com/template/joomla/download-beluga" data-style="6" data-toggle="tab" href="#beluga" rel="https://demo.arrowthemes.com/joomla/beluga/?style=,default,blue,olive,orange,purple,navy" role="tab"><span class="title">Beluga</span> <span class="badge">hot</span></a>
									</li>
									<li>
										<a data-buy="https://arrowthemes.com/template/joomla/download-lawford" data-style="6" data-toggle="tab" href="#lawford" rel="https://demo.arrowthemes.com/joomla/lawford/?style=,default,blue,eminence,khaki,merlot,thunderbird" role="tab"><span class="title">Lawford</span></a>
									</li>
									<li>
										<a data-buy="https://arrowthemes.com/template/joomla/download-utouch" data-style="2" data-toggle="tab" href="#utouch" rel="https://demo.arrowthemes.com/joomla/utouch/?style=,default,neptune" role="tab"><span class="title">Utouch</a>
									</li>
									<li>
										<a data-buy="https://arrowthemes.com/template/joomla/download-buckle" data-style="7" data-toggle="tab" href="#buckle" rel="https://demo.arrowthemes.com/joomla/buckle/?style=,default,blue,green,red,violet,yellow,espresso" role="tab"><span class="title">Buckle</span> <span class="badge">hot</span></a>
									</li>
									<li>
										<a data-buy="https://arrowthemes.com/template/joomla/download-recover" data-style="6" data-toggle="tab" href="#recover" rel="https://demo.arrowthemes.com/joomla/recover?style=,default,cyan,green,teal,rose,indigo" role="tab"><span class="title">Recover</span></a>
									</li>
									<li>
										<a data-buy="https://arrowthemes.com/template/joomla/download-gravity" data-style="8" data-toggle="tab" href="#gravity" rel="https://demo.arrowthemes.com/joomla/gravity?style=,default,stratos,cinnabar,plum,cardinal,conifer,orange,navy" role="tab"><span class="title">Gravity</span> <span class="badge">hot</span></a>
									</li>
									<li>
										<a data-buy="https://arrowthemes.com/template/joomla/download-sandal" data-style="9" data-toggle="tab" href="#sandal" rel="https://demo.arrowthemes.com/joomla/sandal?style=,default,cello,marigold,salmon,tangerine,malta,royal,carnation,coral" role="tab"><span class="title">Sandal</span> <span class="badge">hot</span></a>
									</li>
									<li>
										<a data-buy="https://arrowthemes.com/template/joomla/download-gaucho" data-style="7" data-toggle="tab" href="#gaucho" rel="https://demo.arrowthemes.com/joomla/gaucho?style=,default,espresso,paprika,calico,tangelo,indigo,black" role="tab"><span class="title">Gaucho</span></a>
									</li>
									<li>
										<a data-buy="https://arrowthemes.com/template/joomla/download-celsius" data-style="6" data-toggle="tab" href="#celsius" rel="https://demo.arrowthemes.com/joomla/celsius?style=,default,olive,saffron,orange,rose,azure" role="tab"><span class="title">Celsius</span></a>
									</li>
									<li>
										<a data-buy="https://arrowthemes.com/template/joomla/download-saffron" data-style="6" data-toggle="tab" href="#saffron" rel="https://demo.arrowthemes.com/joomla/saffron?style=,default,valencia,blue,orange,tacha,alpine" role="tab"><span class="title">Saffron</span></a>
									</li>
									<li>
										<a data-buy="https://arrowthemes.com/template/joomla/download-legend" data-style="5" data-toggle="tab" href="#legend" rel="https://demo.arrowthemes.com/joomla/legend?profile=,default,tangerine,mandalay,blue,valencia" role="tab"><span class="title">Legend</span></a>
									</li>
									<li>
										<a data-buy="https://arrowthemes.com/template/joomla/download-lighthouse" data-style="5" data-toggle="tab" href="#lighthouse" rel="https://demo.arrowthemes.com/joomla/lighthouse?profile=,default,olive,azure,mustard,salmon" role="tab"><span class="title">Lighthouse</span> <span class="badge">hot</span></a>
									</li>
									<li>
										<a data-buy="https://arrowthemes.com/template/joomla/download-fidelity" data-style="3" data-toggle="tab" href="#fidelity" rel="https://demo.arrowthemes.com/joomla/fidelity?profile=,default,green,tangerine" role="tab"><span class="title">Fidelity</span></a>
									</li>
									<li>
										<a data-buy="https://arrowthemes.com/template/joomla/download-fontaine" data-style="6" data-toggle="tab" href="#fontaine" rel="https://demo.arrowthemes.com/joomla/fontaine?profile=,default,green,blue,salmon,turquoise,astral" role="tab"><span class="title">Fontaine</span> <span class="badge">hot</span></a>
									</li>
									<li>
										<a data-buy="https://arrowthemes.com/template/joomla/download-uneedo" data-style="6" data-toggle="tab" href="#uneedo" rel="https://demo.arrowthemes.com/joomla/uneedo?profile=,default,rose,green,red,orange,tan" role="tab"><span class="title">Uneedo</span></a>
									</li>
								</ul>
							</div>
							<div class="item active2">
								<ul class="tm-switcher" role="tablist">
									<li>
										<a data-buy="https://arrowthemes.com/template/joomla/download-vantage" data-style="5" data-toggle="tab" href="#vantage" rel="https://demo.arrowthemes.com/joomla/vantage?profile=,default,red,green,blue,lavender" role="tab"><span class="title">Vantage</span></a>
									</li>
									<li>
										<a data-buy="https://arrowthemes.com/template/joomla/download-mistral" data-style="5" data-toggle="tab" href="#mistral" rel="https://demo.arrowthemes.com/joomla/mistral?profile=,default,tangerine,rosewood,flamingo,saffron" role="tab"><span class="title">Mistral</span></a>
									</li>
									<li>
										<a data-buy="https://arrowthemes.com/template/joomla/download-sauna" data-style="4" data-toggle="tab" href="#sauna" rel="https://demo.arrowthemes.com/joomla/sauna?profile=,default,green,pinewood,rose" role="tab"><span class="title">Sauna</span></a>
									</li>
									<li>
										<a data-buy="https://arrowthemes.com/template/joomla/download-abana" data-style="5" data-toggle="tab" href="#abana" rel="https://demo.arrowthemes.com/joomla/abana?profile=,default,green,rose,tangerine,rosewood" role="tab"><span class="title">Abana</span></a>
									</li>
								</ul>
							</div>
						</div>
						<div class="buttons-panel">
							<a class="right carousel-control" data-slide="prev" href="#themes-gallery" role="button"></a> <a class="left carousel-control" data-slide="next" href="#themes-gallery" role="button"></a>
						</div>
					</div>
				</div>
			</div>
			<div class="tm-style-selector pull-left">
				<ul class=""></ul>
			</div>
			<div class="size-themes pull-left">
				<ul>
					<li>
						<a class="icon-size-mobile 375px active" href="" title="375"></a>
					</li>
					<li>
						<a class="icon-size-tablet 768px" href="" title="768"></a>
					</li>
					<!--li>
						<a class="icon-size-tablet-h 1024px" href="" title="1024"></a>
					</li>
					<li>
						<a class="icon-size-desktop 1280px" href="" title="1280"></a>
					</li-->
				</ul>
				<div>
					<a class="reset pull-left" href=""></a>
				</div>
			</div>
			<a class="tm-remove-frame" href="https://arrowthemes.com/">
				<img src="images/close-button.svg" width="13" height="13"><span>Remove Frame</span>
			</a>
			<a class="button purchase mini purchase-link" href="https://arrowthemes.com/" onclick="ga('send','event','Template purchase','Click','Go to Themeforest');">Buy now</a>
		</div>
	</div>
	<!-- Demo Templates Show -->
	<div id="resizer">
		<iframe id="iframe" name="iframe" src="https://demo.arrowthemes.com/joomla/beluga/" style="width:100%;display:block;border:0;"></iframe>
	</div>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.4/jquery.min.js"></script>
	<script src="js/theme.js"></script> 
	<script src="js/core.min.js"></script>
</body>
</html>